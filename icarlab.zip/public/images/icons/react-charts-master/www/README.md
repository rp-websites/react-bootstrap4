# React-Static - Documentation Example

This example includes:

* Styled-Components
* Basic Documentation Setup w/ styles

To get started:

1.  Run `react-static create` and use the `documentation` template.
2.  Follow installation instructions
3.  Edit `TODO` commented items `static.config.js
