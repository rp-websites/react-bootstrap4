import React from 'react'
import { Code } from 'react-smackdown'

//

export default props => <Code language="javascript" {...props} />
